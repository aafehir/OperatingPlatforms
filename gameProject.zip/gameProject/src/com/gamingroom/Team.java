//Aaron Fehir
//March 27, 2021
//Operating Platforms
//Project One

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//Create Team class as child of parent Entity
public class Team extends Entity {
    
	/**
	 * A list of the active players
	 */
	private static List<Player> players = new ArrayList<Player>();
	
	//Constructor
	Team (long id, String name) {
		super (id, name);
	}
	
	//Method to add a player to the list of active players
	public Player addPlayer(String name) {

			// a local player instance
			Player player = null;

			//Use iterator to look for existing player with same name
			//This iterator pattern is useful here because it allows us to easily iterate through the current list of available players
			//If the player already exists, it is not duplicated in the list
			Iterator<Player> it = players.iterator();
			  while(it.hasNext()) {
			     player = it.next();
			     if(player.getName().equals(name)) {
			        return player;
			     }
			     else {
			    	 player = null;
			     }
			  }

			// if not found, make a new player instance and add to list of players
		    if (player == null) {
		       long temp = GameService.getNextPlayerId();
		       player = new Player(temp++, name);
			   players.add(player);
		    }
			// return the new/existing player instance to the caller
			return player;
		}
	
	@Override
	public String toString() {
		return "Team" + super.toString();
	}
}
