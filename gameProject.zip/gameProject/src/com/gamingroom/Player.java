//Aaron Fehir
//March 27, 2021
//Operating Platforms
//Project One

package com.gamingroom;

//Create Player class as child of parent Entity
public class Player extends Entity {
	
	//Constructor
	Player (long id, String name) {
		super (id, name);
	}

	@Override
	public String toString() {
		return "Player" + super.toString();
	}
}
