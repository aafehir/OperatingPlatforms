//Aaron Fehir
//March 27, 2021
//Operating Platforms
//Project One

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next identifier
	 */
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;
    
	//An instance of the gameService class object is created
	//The instance is private so that it cannot be re-created outside of this class
	//The instance is static so that it persists outside of this class
	//The result is that there is one and only one GameService instance at a time
	//This "single" instance is useful so that only one instance of our game exists in memory for as long as our program runs
	private static GameService instance = new GameService();
    
	//The default constructor is made private so that it cannot be called to create additional objects
	private GameService() {}
	
	//In place of calling the constructor, we have a GetInstance() method that points to the one single GameService object
	public static GameService getInstance(){
	      return instance;
	}
	
	//Method to add a game to the list of active games
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		//Use iterator to look for existing game with same name
		//This iterator pattern is useful here because it allows us to easily iterate through the current list of available games
		//If the game already exists, it is not duplicated in the list
		Iterator<Game> it = games.iterator();
		  while(it.hasNext()) {
		     game = it.next();
		     if(game.getName().equals(name)) {
		        return game;
		     }
		     else {
		    	 game = null;
		     }
		  }

		// if not found, make a new game instance and add to list of games
	    if (game == null) {
	       game = new Game(nextGameId++, name);
		   games.add(game);
	    }
		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// Use iterator to look for existing game with same id
		// This will allow us to retrieve the desired game from the list of active games, placing it into memory so that it can be played 
		// if found, simply assign that instance to the local variable
		Iterator<Game> it = games.iterator();
		  while(it.hasNext()) {
		     game = it.next();
		     if(game.getId() == id) {
		        game = it.next();
		     }
		  }
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// Use iterator to look for existing game with same name
		// This will allow us to retrieve the desired game from the list of active games, placing it into memory so that it can be played
		// if found, simply assign that instance to the local variable
		Iterator<Game> it = games.iterator();
		  while(it.hasNext()) {
		     game = it.next();
		     if(game.getName().equals(name)) {
		        game = it.next();
		     }
		  }

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	public static long getNextPlayerId () {
		return nextPlayerId;
	}
	
	public static long getNextTeamId() {
		return nextTeamId;
	}
}
