//Aaron Fehir
//March 27, 2021
//Operating Platforms
//Project One

package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//Create Game class as child of parent Entity
public class Game extends Entity {
	
	/**
	 * A list of the active teams
	 */
	private static List<Team> teams = new ArrayList<Team>();
	
	
	//Constructor
	Game (long id, String name) {
		super (id, name);
	}
	
	//Method to add a team to the list of active teams
	public Team addTeam(String name) {

			// a local team instance
			Team team = null;

			//Use iterator to look for existing team with same name
			//This iterator pattern is useful here because it allows us to easily iterate through the current list of available teams
			//If the team already exists, it is not duplicated in the list
			Iterator<Team> it = teams.iterator();
			  while(it.hasNext()) {
			     team = it.next();
			     if(team.getName().equals(name)) {
			        return team;
			     }
			     else {
			    	 team = null;
			     }
			  }

			// if not found, make a new team instance and add to list of teams
		    if (team == null) {
		       long temp = GameService.getNextTeamId();
		       team = new Team(temp++, name);
			   teams.add(team);
		    }
			// return the new/existing team instance to the caller
			return team;
		}
	
	@Override
	public String toString() {
		return "Game" + super.toString();
	}
}
