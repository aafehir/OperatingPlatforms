//Aaron Fehir
//March 27, 2021
//Operating Platforms
//Project One


package com.gamingroom;

public class Entity {
	
	//instance variables
	private long id;
	private String name;
	
	//Constructors
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Entity() {
	
	}
	
	Entity (long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	//public functions
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
    
	public String toString() {	
		return "[id=" + id + ", name=" + name + "]";
	}
}